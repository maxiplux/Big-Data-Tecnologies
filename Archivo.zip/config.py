# -*- coding: utf-8 -*-
import os
import  os
consumer_key = 'XqS57zAjgQfkjnCnVeOP5g'
consumer_secret = 'dYrsaxWfncWnNVPnjaLNrxZdihxJXjzkBOtRbO3UY6A'
access_token = '17996901-LwSSjZXS9YPZOy7quSL7hwd1w0OfMp0rHWVTcZXOO'
access_token_secret = 'JINn7zsyQ5L0BiQ9wNcSoKp0wfiqRwgJPqLDyP5xpjUxN'

TWITTER_MAX_NUM_HASHTAG=5
COUNTRY_WOE_ID=23424977
KAFKA_SERVER='localhost:9092'



PATH_TO = os.path.join(os.getcwd(), "solution/{id}dataset.json")
SECONDS=60
TIME_TO_SLEEP_BY_NEXT_TWEETS=SECONDS*10
TIME_TO_SLEEP_BY_NEXT_TWEETS_ERROR=SECONDS*30
KAFKA_TOPIC="tweets"


MAIN_HOST="quickstart.cloudera"
HBASE_TABLE = "infographis"
HBASE_HOST = MAIN_HOST
HDFS_HOST=MAIN_HOST